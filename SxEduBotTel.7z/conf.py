#configuration class file
class Conf():
    def __init__(self):
        #self.HTTP_API = "1788019605:AAEE3dR0BpzSaiaN2xZcdcqyw49SKxc6UOY" //MY
        self.HTTP_API = "1720198317:AAHhBGMMZv6xuMLYvJzORNBEEupw5BGsflo"  #KATE